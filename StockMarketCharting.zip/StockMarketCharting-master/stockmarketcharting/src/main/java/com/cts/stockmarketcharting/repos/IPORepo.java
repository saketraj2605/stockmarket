package com.cts.stockmarketcharting.repos;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.stockmarketcharting.entity.IPODetail;

public interface IPORepo extends JpaRepository<IPODetail, Integer> {

	
}

package com.cts.stockmarketcharting.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;


@Entity
@Table(name = "Company")
@NamedQuery(name = "Company.findAllActivatedCompany",
query = "SELECT c FROM Company c where active=1")
public class Company {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "Company_id")
	private int id;
	
	@Column(name="Company_active")
	private boolean active;

	@NotNull(message = "Name cannot be empty!")
	@Column(name = "Company_name")
	@Size(max = 70, message = "Name cannot exceed 70 characters!")
	private String companyName;
	
	@NotNull(message = "Name cannot be empty!")
	@Column(name = "Company_turnover")
	private double turnover;
	
	@NotNull(message = "Name cannot be empty!")
	@Column(name = "Company_ceo")
	private String ceo;
	
	@Column(name = "Company_directors")
	private String boardOfDirectors;
	
	
	@Column(name="Company_stock_exchanges")
	private String stockExchanges;
	
	@OneToOne
	@JoinColumn(name="sector_id")
	private Sector sector;
	
	@NotNull(message = "Name cannot be empty!")
	@Column(name = "Company_about")
	private String about;
	
	
	@Column(name = "Company_stockCode")
	private int stockCode;
	
		
	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public double getTurnover() {
		return turnover;
	}

	public void setTurnover(double turnover) {
		this.turnover = turnover;
	}

	public String getCeo() {
		return ceo;
	}

	public void setCeo(String ceo) {
		this.ceo = ceo;
	}

	public String getBoardOfDirectors() {
		return boardOfDirectors;
	}

	public void setBoardOfDirectors(String boardOfDirectors) {
		this.boardOfDirectors = boardOfDirectors;
	}

	public String getStockExchanges() {
		return stockExchanges;
	}

	public void setStockExchanges(String stockExchanges) {
		this.stockExchanges = stockExchanges;
	}

	public Sector getSector() {
		return sector;
	}

	public void setSector(Sector sector) {
		this.sector = sector;
	}

	public String getAbout() {
		return about;
	}

	public void setAbout(String about) {
		this.about = about;
	}

	public int getStockCode() {
		return stockCode;
	}

	public void setStockCode(int stockCode) {
		this.stockCode = stockCode;
	}
	
	public Company(int id, String companyName, double turnover, String ceo, String boardOfDirectors,
			String stockExchanges, Sector sector, String about, int stockCode, boolean active) {
		super();
		this.id = id;
		this.companyName = companyName;
		this.turnover = turnover;
		this.ceo = ceo;
		this.boardOfDirectors = boardOfDirectors;
		this.stockExchanges = stockExchanges;
		this.sector = sector;
		this.about = about;
		this.stockCode = stockCode;
		this.active=active;
	}

	public Company() {
		super();
	}

	@Override
	public String toString() {
		return "Company [id=" + id + ", companyName=" + companyName + ", turnover=" + turnover + ", ceo=" + ceo
				+ ", boardOfDirectors=" + boardOfDirectors + ", stockExchanges=" + stockExchanges + ", sector=" + sector
				+ ", about=" + about + ", stockCode=" + stockCode + ", active=" + active + "]";
	}

	
	
	

}

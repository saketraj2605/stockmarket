package com.cts.stockmarketcharting.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.cts.stockmarketcharting.entity.Company;
import com.cts.stockmarketcharting.entity.Sector;
import com.cts.stockmarketcharting.repos.CompanyRepo;
import com.cts.stockmarketcharting.repos.SectorRepo;
import com.cts.stockmarketcharting.service.CompanyService;

@RestController
public class CompanyController {
	
	@Autowired
	CompanyRepo companyRepo;
	
	@Autowired
	SectorRepo sectorRepo;
	
	@Autowired
	CompanyService companyService;
	

	@RequestMapping(path="/company/{name}", method=RequestMethod.GET)
	public ResponseEntity<Company> getCompanyByTitle(@PathVariable("name") String name){

		Company companyFound =  companyService.findCompanyByName(name);
		ResponseEntity<Company> status = null;
		if(companyFound==null){
			status = new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
		else{
			status = new ResponseEntity<>(companyFound,HttpStatus.OK);
			
			
		}
		System.out.println(companyFound);
		return status;

	}
	
	@RequestMapping(path="/companies", method=RequestMethod.GET)
	public List<Company> getCompanies(){
		System.out.println("Hitting controller");

		return companyService.findAll();
	}
	@RequestMapping(path="/company/{sector}", method=RequestMethod.POST)
	public ResponseEntity<Void> addCompany(@RequestBody Company company, @PathVariable("sector") String sector ){
		Sector sectors=sectorRepo.findSectorBySectorName(sector);
		company.setSector(sectors);
		companyService.save(company);
		ResponseEntity<Void> status = new ResponseEntity<>(HttpStatus.CREATED);
		return status;

		
	}
	
	@RequestMapping(path="/company/deactive/{name}", method=RequestMethod.POST)
	public ResponseEntity<String> deactivate(@PathVariable("name") String name)
	{
		ResponseEntity<String> status;
		System.out.println(name);
		Company company=companyService.findCompanyByName(name);
		if(company==null)
		{
			status = new ResponseEntity<>("Company Not Found",HttpStatus.NOT_FOUND);
		}
		else
		{
			companyService.deactivate(company);
			status = new ResponseEntity<>("Company Deactivated",HttpStatus.OK);
			
		}
		return status;
	}
	
	@RequestMapping(path="/company/update/{sector}", method=RequestMethod.POST)
	public ResponseEntity<String> update(@RequestBody Company company,@PathVariable("sector") String sector )
	{
		ResponseEntity<String> status;
		Company companies=companyService.findCompanyByName(company.getCompanyName());
		Sector sectors=sectorRepo.findSectorBySectorName(sector);
		if(companies==null)
		{
			status = new ResponseEntity<>("Company Not Found",HttpStatus.NOT_FOUND);
		}
		else
		{
			companies.setSector(sectors);
			companyService.save(companies);
			status = new ResponseEntity<>("Company Details Changed",HttpStatus.OK);
			
		}
		return status;
	}

}
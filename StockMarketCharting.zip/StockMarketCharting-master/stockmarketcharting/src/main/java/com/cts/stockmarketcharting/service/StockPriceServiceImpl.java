package com.cts.stockmarketcharting.service;

import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.cts.stockmarketcharting.entity.StockPrice;
import com.cts.stockmarketcharting.repos.StockPriceRepo;

@Service
public class StockPriceServiceImpl implements StockPriceService {
	
	
	@Autowired
	StockPriceRepo stockPriceRepo;
	
	
	XSSFWorkbook workbook;

	@Override
	public void readFile(MultipartFile reapExcelDataFile)
	{
			
		
		try {
			workbook = new XSSFWorkbook(reapExcelDataFile.getInputStream());
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
	    XSSFSheet worksheet = workbook.getSheetAt(0);

	    for(int i=1;i<worksheet.getPhysicalNumberOfRows() ;i++) {
	    	StockPrice stockPrice = new StockPrice();

	        XSSFRow row = worksheet.getRow(i);
	        int companyCode=(int) row.getCell(1).getNumericCellValue();
	        stockPrice.setCompanyCode(companyCode);
	        String stockExchange=(String) row.getCell(2).getStringCellValue();
	        stockPrice.setStockExchange(stockExchange);
	        stockPrice.setCurrentPrice((int) row.getCell(3).getNumericCellValue());
	       	stockPrice.setDate(row.getCell(4).getDateCellValue());
			stockPrice.setTime(row.getCell(5).getDateCellValue());
			stockPriceRepo.save(stockPrice);
	        
		
	}

	}
}

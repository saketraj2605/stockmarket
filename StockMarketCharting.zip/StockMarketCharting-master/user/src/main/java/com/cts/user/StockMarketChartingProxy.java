package com.cts.user;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.cloud.netflix.ribbon.RibbonClient;

import com.cts.user.entity.Company;

@FeignClient(name="netflix-zuul-api-gateway-server")
@RibbonClient(name="stockmarketcharting")
public interface StockMarketChartingProxy {
	
	@GetMapping("/stockmarketcharting/companies")
	public List<Company> getCompanies();

}
